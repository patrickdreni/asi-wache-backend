// React Native Startpunkt
