// Beispielhafter Startpunkt für Backend
