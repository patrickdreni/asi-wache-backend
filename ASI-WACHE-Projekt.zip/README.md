
# ASI-WACHE Zeiterfassungs-App

## Struktur:
- **backend/**: Node.js + Express API mit Beispielrouten
- **mobile-app/**: React Native Basisstruktur für Mitarbeiter-App
- **admin-panel/**: React Admin Interface (Web)
- **logo/**: Enthält das Projektlogo
